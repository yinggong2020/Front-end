<?php

$gender = $_GET['gender'];
$year = $_GET['year'];

$con = mysqli_connect('localhost','root','root','SSA');


if($con){
	if($year == ''  && $gender == ''){
		$sql = "SELECT * FROM BabyNames ORDER BY year,gender,ranking;";
	} else if ($year == ''){
		$sql = "SELECT * FROM BabyNames WHERE gender = '$gender' ORDER BY year,gender,ranking;";
	} else if ($gender == '') {
		$sql = "SELECT * FROM BabyNames WHERE year = '$year' ORDER BY year,gender,ranking;";
	} else {
		$sql = "SELECT * FROM BabyNames WHERE gender = '$gender' AND year = '$year' ORDER BY year,gender,ranking;";
	}


	$result = mysqli_query($con,$sql);

	if (mysqli_num_rows($result) != 0 ){
		
		echo " <br> ";
		echo " Top-Five Popular Names  ";     
		echo "<table border='1' bgcolor='#C8C8C8'><tr><th>Name</th> <th>Ranking</th> <th>Gender</th> <th>Year</th> </tr>";

		while ($row = mysqli_fetch_array($result)) {
			echo "<tr>";
			echo "<td>" . $row['name'] . "</td>";
			echo "<td>" . $row['ranking'] . "</td>";
			echo "<td>" . $row['gender'] . "</td>";
			echo "<td>" . $row['year'] . "</td>";
			echo "</tr>";
		}
		echo"</table>";
	}else{
		echo "no record found !!!!! ";
	}

}else{
	echo "Unable to connect to database!";
	echo "Debugging errno" . mysqli_connect_errno();
}


?>